import './App.css';
import React, { useEffect, useState } from 'react'; 
import axios from 'axios';

const TaskList = (props) => (
  <div>
  {props.data.map(data => <Task key={data.id} {...data} deleteTask={props.deleteTask} />)}
  </div>
);

const Task =(props) =>{
  const handleDeleteTask = ()=>{
    props.deleteTask(props.id);
  };

  return(
  <div classNane="OneTask">
      <div className="TaskName">{props.name}</div>
      <button type="button" id="del" onClick={handleDeleteTask} className="YN">Delete</button>
      <button type="button" id="add" className="YN">Insert</button>
  </div>
  );
}

const Mainform = (props) => {
  const [taskName, setTaskName] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    const newData = { name: taskName };
    props.onSubmit(newData);
    setTaskName('');
  };

  return (
    <form>
      <input
        type="text"
        placeholder="Task name"
        value={taskName}
        onChange={event => setTaskName(event.target.value)}
        required
      />
      <button type="button" className="btn" onClick={handleSubmit}>Add task</button>
    </form>
  );
}


const App = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/Tasks')
      .then(response => setData(response.data))
      .catch(error => console.error(error));
  }, []);

  const addNewTask = (taskData) => {
    //const newTask = { ...taskData, id: taskIdCounter++ }; // Assign a unique id using Date.now()
    //setData(prevData => [...prevData, newTask]);
    
    //add to db.json
    axios.post('http://localhost:3000/Tasks', taskData)
    .then(response => setData(prevData => [...prevData, response.data]))
    .catch(error => console.error(error));
  };

  const deleteTask = (taskId) =>{
    //setData((prevData) => prevData.filter((task) => task.id !== taskId));
    //delete from db.json
    axios.delete(`http://localhost:3000/Tasks/${taskId}`)
    .then(() => setData(prevData => prevData.filter(task => task.id !== taskId)))
    .catch(error => console.error(error));
  };

  return (
    <div className="MainApp">
      <div className="header">Task List</div>
      <Mainform onSubmit={addNewTask} />
      <TaskList data={data} deleteTask={deleteTask}/>
    </div>
  );
}
export default App;
